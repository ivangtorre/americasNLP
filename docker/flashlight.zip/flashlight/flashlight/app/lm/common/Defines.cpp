/*
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT-style license found in the
 * LICENSE file in the root directory of this source tree.
 */

#include "flashlight/app/lm/common/Defines.h"

namespace fl {
namespace app {
namespace lm {

/* Place holder */

} // namespace lm
} // namespace app
} // namespace fl
