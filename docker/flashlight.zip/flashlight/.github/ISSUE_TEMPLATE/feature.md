---
name: Feature Request
about: Request a feature to be added
title: "[Feature request title here]"
labels: enhancement

---

### Feature Description
[A clear, concise description of the feature]

#### Use Case
[Example usage of the feature - why is it needed?]

#### Additional Context
[Add any additional information here]
