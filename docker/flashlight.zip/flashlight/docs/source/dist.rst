Distributed Library
===================

.. doxygengroup:: distributed_api
    :content-only:


Reducer Framework
-----------------

.. doxygenclass:: fl::Reducer
   :members:
   :undoc-members:

Reducers
--------

.. doxygenclass:: fl::InlineReducer
   :members:
   :undoc-members:

.. doxygenclass:: fl::CoalescingReducer
   :members:
   :undoc-members:
