Optimization
============

.. _optimizers:

Optimizers
----------

FirstOrderOptimizer
^^^^^^^^^^^^^^^^^^^
.. doxygenclass:: fl::FirstOrderOptimizer
   :members:
   :undoc-members:

AdamOptimizer
^^^^^^^^^^^^^
.. doxygenclass:: fl::AdamOptimizer
   :members:
   :undoc-members:

RMSPropOptimizer
^^^^^^^^^^^^^^^^
.. doxygenclass:: fl::RMSPropOptimizer
   :members:
   :undoc-members:

SGDOptimizer
^^^^^^^^^^^^
.. doxygenclass:: fl::SGDOptimizer
   :members:
   :undoc-members:
