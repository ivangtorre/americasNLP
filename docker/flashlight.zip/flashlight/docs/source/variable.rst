.. _variable:

Variable
---------

.. doxygenclass:: fl::Variable
   :members:
   :undoc-members:
