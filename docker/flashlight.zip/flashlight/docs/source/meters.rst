.. _meters:

Meters
======

AverageValueMeter
-----------------
.. doxygenclass:: fl::AverageValueMeter
   :members:
   :undoc-members:

CountMeter
----------
.. doxygenclass:: fl::CountMeter
   :members:
   :undoc-members:

EditDistanceMeter
-----------------
.. doxygenclass:: fl::EditDistanceMeter
   :members:
   :undoc-members:

MSEMeter
--------
.. doxygenclass:: fl::MSEMeter
   :members:
   :undoc-members:

FrameErrorMeter
---------------
.. doxygenclass:: fl::FrameErrorMeter
   :members:
   :undoc-members:

TimeMeter
---------
.. doxygenclass:: fl::TimeMeter
   :members:
   :undoc-members:
