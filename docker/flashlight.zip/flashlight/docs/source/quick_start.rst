Quick Start
===========

Some very simple examples using Variable, Module,
Container and building to put it all together.
